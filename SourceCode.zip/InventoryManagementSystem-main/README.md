# InventoryManagementSystem
run script in pgAdmin4 to create tables and sample data
